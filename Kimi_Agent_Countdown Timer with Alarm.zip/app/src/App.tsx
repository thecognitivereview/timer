import { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, RotateCcw, Settings, X, Check, Volume2, VolumeX } from 'lucide-react';
import './App.css';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

interface TimerInput {
  days: string;
  hours: string;
  minutes: string;
  seconds: string;
}

function App() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [initialTime, setInitialTime] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isRunning, setIsRunning] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [timerInput, setTimerInput] = useState<TimerInput>({ days: '0', hours: '0', minutes: '0', seconds: '0' });
  const [shake, setShake] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isAlarmPlaying, setIsAlarmPlaying] = useState(false);
  
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const buttonRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize audio element
  useEffect(() => {
    audioRef.current = new Audio('/timer/alarm.mp3');
    audioRef.current.loop = true;
    
    // Load mute preference
    const savedMute = localStorage.getItem('countdownTimerMuted');
    if (savedMute) {
      setIsMuted(savedMute === 'true');
    }
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  // Load saved timer from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('countdownTimer');
    if (saved) {
      try {
        const { time, running, timestamp } = JSON.parse(saved);
        const elapsed = Math.floor((Date.now() - timestamp) / 1000);
        const totalSeconds = (time.days * 86400) + (time.hours * 3600) + (time.minutes * 60) + time.seconds;
        const remaining = Math.max(0, totalSeconds - elapsed);
        
        const newTimeLeft = {
          days: Math.floor(remaining / 86400),
          hours: Math.floor((remaining % 86400) / 3600),
          minutes: Math.floor((remaining % 3600) / 60),
          seconds: remaining % 60
        };
        
        setTimeLeft(newTimeLeft);
        setInitialTime(newTimeLeft);
        setTimerInput({
          days: String(time.days),
          hours: String(time.hours),
          minutes: String(time.minutes),
          seconds: String(time.seconds)
        });
        
        if (running && remaining > 0) {
          setIsRunning(true);
        }
      } catch (e) {
        console.error('Failed to load saved timer:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Save timer state to localStorage
  const saveTimerState = useCallback((running: boolean) => {
    const state = {
      time: initialTime,
      running,
      timestamp: Date.now()
    };
    localStorage.setItem('countdownTimer', JSON.stringify(state));
  }, [initialTime]);

  // Play alarm sound
  const playAlarm = useCallback(() => {
    if (audioRef.current && !isMuted) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(e => console.log('Audio play failed:', e));
      setIsAlarmPlaying(true);
    }
  }, [isMuted]);

  // Stop alarm sound
  const stopAlarm = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsAlarmPlaying(false);
  }, []);

  // Timer countdown logic
  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(prev => {
          const totalSeconds = (prev.days * 86400) + (prev.hours * 3600) + (prev.minutes * 60) + prev.seconds;
          if (totalSeconds <= 0) {
            setIsRunning(false);
            setIsComplete(true);
            setShake(true);
            setTimeout(() => setShake(false), 500);
            playAlarm();
            if (intervalRef.current) clearInterval(intervalRef.current);
            return { days: 0, hours: 0, minutes: 0, seconds: 0 };
          }
          
          const newTotal = totalSeconds - 1;
          return {
            days: Math.floor(newTotal / 86400),
            hours: Math.floor((newTotal % 86400) / 3600),
            minutes: Math.floor((newTotal % 3600) / 60),
            seconds: newTotal % 60
          };
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, playAlarm]);

  // Save state when running changes
  useEffect(() => {
    if (isLoaded) {
      saveTimerState(isRunning);
    }
  }, [isRunning, isLoaded, saveTimerState]);

  const formatNumber = (num: number): string => {
    return num.toString().padStart(2, '0');
  };

  const handleStart = () => {
    const totalSeconds = (timeLeft.days * 86400) + (timeLeft.hours * 3600) + (timeLeft.minutes * 60) + timeLeft.seconds;
    if (totalSeconds > 0) {
      setIsRunning(true);
      setIsComplete(false);
    }
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setIsComplete(false);
    setTimeLeft(initialTime);
    stopAlarm();
  };

  const handleSetTimer = () => {
    const days = Math.min(365, Math.max(0, parseInt(timerInput.days) || 0));
    const hours = Math.min(23, Math.max(0, parseInt(timerInput.hours) || 0));
    const minutes = Math.min(59, Math.max(0, parseInt(timerInput.minutes) || 0));
    const seconds = Math.min(59, Math.max(0, parseInt(timerInput.seconds) || 0));
    
    const newTime = { days, hours, minutes, seconds };
    setTimeLeft(newTime);
    setInitialTime(newTime);
    setIsRunning(false);
    setIsComplete(false);
    setShowSettings(false);
    stopAlarm();
    
    // Save the new state
    const state = {
      time: newTime,
      running: false,
      timestamp: Date.now()
    };
    localStorage.setItem('countdownTimer', JSON.stringify(state));
  };

  const handleInputChange = (field: keyof TimerInput, value: string) => {
    // Allow only numbers
    const cleaned = value.replace(/[^0-9]/g, '');
    setTimerInput(prev => ({ ...prev, [field]: cleaned }));
  };

  // Toggle mute
  const toggleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    localStorage.setItem('countdownTimerMuted', String(newMuted));
    if (newMuted && audioRef.current) {
      audioRef.current.pause();
      setIsAlarmPlaying(false);
    } else if (isAlarmPlaying && audioRef.current) {
      audioRef.current.play().catch(e => console.log('Audio play failed:', e));
    }
  };

  // Magnetic button effect
  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>, index: number) => {
    const btn = buttonRefs.current[index];
    if (!btn) return;
    
    const rect = btn.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    
    btn.style.transform = `translate(${x * 0.2}px, ${y * 0.2}px)`;
  };

  const handleMouseLeave = (index: number) => {
    const btn = buttonRefs.current[index];
    if (btn) {
      btn.style.transform = 'translate(0, 0)';
    }
  };

  const totalSeconds = (timeLeft.days * 86400) + (timeLeft.hours * 3600) + (timeLeft.minutes * 60) + timeLeft.seconds;

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      {/* Background Image */}
      <div 
        className="absolute inset-0 animate-breathe"
        style={{
          backgroundImage: 'url(/timer/hero-bg.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          transform: 'scale(1.05)'
        }}
      />
      
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/70" />
      
      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        {/* Header */}
        <div className={`mb-8 transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-10'}`}>
          <h1 className="text-4xl md:text-6xl font-black tracking-wider text-center">
            <span className="inline-block">C</span>
            <span className="inline-block">O</span>
            <span className="inline-block">U</span>
            <span className="inline-block">N</span>
            <span className="inline-block">T</span>
            <span className="inline-block">D</span>
            <span className="inline-block">O</span>
            <span className="inline-block">W</span>
            <span className="inline-block">N</span>
          </h1>
        </div>
        
        {/* Timer Display */}
        <div className={`mb-12 transition-all duration-1000 delay-300 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div 
            className={`flex items-center justify-center gap-2 md:gap-4 ${shake ? 'animate-shake' : ''}`}
            style={{ perspective: '1000px' }}
          >
            {/* Days */}
            <div className="flex flex-col items-center">
              <div className="flex gap-1">
                <span className={`timer-digit text-6xl sm:text-7xl md:text-8xl lg:text-9xl text-white ${isRunning && timeLeft.seconds % 2 === 0 ? 'animate-pulse-glow' : ''}`}>
                  {formatNumber(timeLeft.days)}
                </span>
              </div>
              <span className="text-xs md:text-sm text-white/60 uppercase tracking-widest mt-2">Days</span>
            </div>
            
            <span className={`timer-separator text-5xl sm:text-6xl md:text-7xl lg:text-8xl animate-blink`}>:</span>
            
            {/* Hours */}
            <div className="flex flex-col items-center">
              <div className="flex gap-1">
                <span className={`timer-digit text-6xl sm:text-7xl md:text-8xl lg:text-9xl text-white ${isRunning && timeLeft.seconds % 2 === 0 ? 'animate-pulse-glow' : ''}`}>
                  {formatNumber(timeLeft.hours)}
                </span>
              </div>
              <span className="text-xs md:text-sm text-white/60 uppercase tracking-widest mt-2">Hours</span>
            </div>
            
            <span className={`timer-separator text-5xl sm:text-6xl md:text-7xl lg:text-8xl animate-blink`}>:</span>
            
            {/* Minutes */}
            <div className="flex flex-col items-center">
              <div className="flex gap-1">
                <span className={`timer-digit text-6xl sm:text-7xl md:text-8xl lg:text-9xl text-white ${isRunning && timeLeft.seconds % 2 === 0 ? 'animate-pulse-glow' : ''}`}>
                  {formatNumber(timeLeft.minutes)}
                </span>
              </div>
              <span className="text-xs md:text-sm text-white/60 uppercase tracking-widest mt-2">Minutes</span>
            </div>
            
            <span className={`timer-separator text-5xl sm:text-6xl md:text-7xl lg:text-8xl animate-blink`}>:</span>
            
            {/* Seconds */}
            <div className="flex flex-col items-center">
              <div className="flex gap-1">
                <span className={`timer-digit text-6xl sm:text-7xl md:text-8xl lg:text-9xl text-[#ffd900] ${isRunning ? 'animate-pulse-glow' : ''}`}>
                  {formatNumber(timeLeft.seconds)}
                </span>
              </div>
              <span className="text-xs md:text-sm text-white/60 uppercase tracking-widest mt-2">Seconds</span>
            </div>
          </div>
        </div>
        
        {/* Controls */}
        <div className={`flex flex-wrap items-center justify-center gap-4 transition-all duration-1000 delay-500 ${isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}>
          {!isRunning ? (
            <button
              ref={el => { buttonRefs.current[0] = el; }}
              onClick={handleStart}
              onMouseMove={(e) => handleMouseMove(e, 0)}
              onMouseLeave={() => handleMouseLeave(0)}
              disabled={totalSeconds === 0}
              className="magnetic-btn px-8 py-4 bg-[#ffd900] text-black font-bold text-lg rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
            >
              <span className="flex items-center gap-2">
                <Play className="w-5 h-5" />
                START
              </span>
            </button>
          ) : (
            <button
              ref={el => { buttonRefs.current[1] = el; }}
              onClick={handlePause}
              onMouseMove={(e) => handleMouseMove(e, 1)}
              onMouseLeave={() => handleMouseLeave(1)}
              className="magnetic-btn px-8 py-4 bg-white/10 text-white font-bold text-lg rounded-lg border border-white/30 hover:bg-white/20 transition-all duration-300"
            >
              <span className="flex items-center gap-2">
                <Pause className="w-5 h-5" />
                PAUSE
              </span>
            </button>
          )}
          
          <button
            ref={el => { buttonRefs.current[2] = el; }}
            onClick={handleReset}
            onMouseMove={(e) => handleMouseMove(e, 2)}
            onMouseLeave={() => handleMouseLeave(2)}
            className="magnetic-btn px-8 py-4 bg-transparent text-white font-bold text-lg rounded-lg border border-white/30 hover:bg-white/10 transition-all duration-300"
          >
            <span className="flex items-center gap-2">
              <RotateCcw className="w-5 h-5" />
              RESET
            </span>
          </button>
          
          <button
            ref={el => { buttonRefs.current[3] = el; }}
            onClick={() => setShowSettings(true)}
            onMouseMove={(e) => handleMouseMove(e, 3)}
            onMouseLeave={() => handleMouseLeave(3)}
            className="magnetic-btn px-8 py-4 bg-transparent text-white font-bold text-lg rounded-lg border border-white/30 hover:bg-white/10 transition-all duration-300"
          >
            <span className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              SET
            </span>
          </button>
          
          {/* Mute Button */}
          <button
            onClick={toggleMute}
            className={`p-4 rounded-lg border transition-all duration-300 ${
              isMuted 
                ? 'bg-red-500/20 border-red-500/50 text-red-400 hover:bg-red-500/30' 
                : 'bg-white/10 border-white/30 text-white hover:bg-white/20'
            }`}
            title={isMuted ? 'Unmute alarm' : 'Mute alarm'}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
        </div>
        
        {/* Progress bar */}
        {initialTime.days > 0 || initialTime.hours > 0 || initialTime.minutes > 0 || initialTime.seconds > 0 ? (
          <div className={`w-full max-w-2xl mt-8 transition-all duration-1000 delay-700 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
            <div className="h-1 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-[#ffd900] transition-all duration-1000 ease-linear"
                style={{ 
                  width: `${Math.max(0, (1 - totalSeconds / (initialTime.days * 86400 + initialTime.hours * 3600 + initialTime.minutes * 60 + initialTime.seconds)) * 100)}%` 
                }}
              />
            </div>
          </div>
        ) : null}
      </div>
      
      {/* Settings Modal */}
      {showSettings && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          onClick={(e) => e.target === e.currentTarget && setShowSettings(false)}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/80 backdrop-blur-lg" />
          
          {/* Modal Content */}
          <div className="relative glass rounded-2xl p-8 w-full max-w-md transform transition-all duration-500 scale-100 opacity-100">
            <button
              onClick={() => setShowSettings(false)}
              className="absolute top-4 right-4 p-2 text-white/60 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            
            <h2 className="text-3xl font-black mb-8 text-center">Set Timer</h2>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              {/* Days */}
              <div className="relative">
                <input
                  type="number"
                  id="days"
                  value={timerInput.days}
                  onChange={(e) => handleInputChange('days', e.target.value)}
                  onFocus={(e) => e.target.select()}
                  className="input-animated w-full text-4xl font-black text-center py-4 bg-transparent text-white rounded-lg"
                  placeholder="0"
                  min="0"
                  max="365"
                />
                <label htmlFor="days" className="block text-center text-sm text-white/60 mt-2 uppercase tracking-wider">
                  Days
                </label>
              </div>
              
              {/* Hours */}
              <div className="relative">
                <input
                  type="number"
                  id="hours"
                  value={timerInput.hours}
                  onChange={(e) => handleInputChange('hours', e.target.value)}
                  onFocus={(e) => e.target.select()}
                  className="input-animated w-full text-4xl font-black text-center py-4 bg-transparent text-white rounded-lg"
                  placeholder="0"
                  min="0"
                  max="23"
                />
                <label htmlFor="hours" className="block text-center text-sm text-white/60 mt-2 uppercase tracking-wider">
                  Hours
                </label>
              </div>
              
              {/* Minutes */}
              <div className="relative">
                <input
                  type="number"
                  id="minutes"
                  value={timerInput.minutes}
                  onChange={(e) => handleInputChange('minutes', e.target.value)}
                  onFocus={(e) => e.target.select()}
                  className="input-animated w-full text-4xl font-black text-center py-4 bg-transparent text-white rounded-lg"
                  placeholder="0"
                  min="0"
                  max="59"
                />
                <label htmlFor="minutes" className="block text-center text-sm text-white/60 mt-2 uppercase tracking-wider">
                  Minutes
                </label>
              </div>
              
              {/* Seconds */}
              <div className="relative">
                <input
                  type="number"
                  id="seconds"
                  value={timerInput.seconds}
                  onChange={(e) => handleInputChange('seconds', e.target.value)}
                  onFocus={(e) => e.target.select()}
                  className="input-animated w-full text-4xl font-black text-center py-4 bg-transparent text-white rounded-lg"
                  placeholder="0"
                  min="0"
                  max="59"
                />
                <label htmlFor="seconds" className="block text-center text-sm text-white/60 mt-2 uppercase tracking-wider">
                  Seconds
                </label>
              </div>
            </div>
            
            <button
              onClick={handleSetTimer}
              className="w-full py-4 bg-[#ffd900] text-black font-bold text-lg rounded-lg hover:bg-[#ffe135] transition-colors flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5" />
              SET TIMER
            </button>
          </div>
        </div>
      )}
      
      {/* Completion Modal */}
      {isComplete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
          
          {/* Modal Content */}
          <div className="relative text-center transform transition-all duration-500 scale-100 opacity-100">
            <h2 className="text-6xl md:text-8xl font-black mb-8 text-[#ffd900] animate-pulse-glow">
              TIME'S UP!
            </h2>
            <div className="flex flex-wrap justify-center gap-4">
              <button
                onClick={() => {
                  handleReset();
                  setIsComplete(false);
                  stopAlarm();
                }}
                className="magnetic-btn px-8 py-4 bg-[#ffd900] text-black font-bold text-lg rounded-lg transition-all duration-300"
              >
                <span className="flex items-center gap-2">
                  <RotateCcw className="w-5 h-5" />
                  RESET
                </span>
              </button>
              <button
                onClick={() => {
                  setIsComplete(false);
                  setShowSettings(true);
                  stopAlarm();
                }}
                className="magnetic-btn px-8 py-4 bg-white/10 text-white font-bold text-lg rounded-lg border border-white/30 hover:bg-white/20 transition-all duration-300"
              >
                <span className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  NEW TIMER
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
