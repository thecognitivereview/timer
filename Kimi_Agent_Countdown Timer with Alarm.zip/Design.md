# Countdown Timer Design

## Overview
- **Motion Style**: Cinematic Time Suspension
- **Animation Intensity**: Ultra-Dynamic
- **Technology Stack**: GSAP (ScrollTrigger, Flip), WebGL (for distortion effects), CSS Variables
- **Core Concept**: "Time as a physical, fluid entity" - elements flow, deform, and react to the countdown's tension.

## Brand Foundation
- **Colors**: 
  - Primary Background: #000000 (Deep Space Black)
  - Accent: #ffd900 (Supernova Yellow)
  - Overlay: rgba(0, 0, 0, 0.7)
  - Text: #ffffff (White)
- **Typography**: 
  - Display: "Raleway" (Weights: 700, 900)
  - Body: "Lato" (Weights: 100-900)
- **Core Message**: Urgency meets precision in a visually stunning temporal experience.

## Global Motion System

### Animation Timing
- **Easing Library**: 
  - `custom-expo`: `cubic-bezier(0.16, 1, 0.3, 1)` for entrances
  - `elastic-snap`: `cubic-bezier(0.68, -0.6, 0.32, 1.6)` for interactions
- **Duration Scale**: 
  - Micro-interactions: 0.2s - 0.4s
  - Structural shifts: 0.8s - 1.2s
- **Stagger Patterns**: 0.05s per digit/character for rapid, fluid readability

### Continuous Effects
- **Living Gradients**: Subtle noise textures shifting on accent elements.
- **Micro-Parallax**: Text and background layers move at slightly different speeds on mouse move (throttled).
- **Time Pulse**: A barely perceptible rhythm (60bpm) that all motion syncs to when idle.

### Scroll Engine
- **Pinning**: The timer section pins the viewport while the background undergoes a "warp speed" transition.
- **Velocity**: Scroll speed influences the "stretch" and blur of the timer digits momentarily.

## Section 1: Hero Header

### Layout
**"Orbital Depth Field"**
Instead of a static background, the timer floats in a 3D Z-space. The background image sits at Z-100, the timer at Z-0, and decorative particles at Z+50.

#### Spatial Composition
- **Container**: Full viewport height (100svh) with perspective: 1000px.
- **Alignment**: Central axis, but elements break the grid boundaries during animation.

### Content
- **Headline**: "COUNTDOWN TIMER" (Split into individual letters for animation)
- **Timer Display**: "00 : 00 : 00 : 00" (Days, Hours, Minutes, Seconds)
- **Controls**: "START", "PAUSE", "RESET"

### Images
**Hero Background Image**
- **Resolution**: 1920x1080 (or higher)
- **Aspect Ratio**: 16:9
- **Transparent Background**: No
- **Visual Style**: Abstract digital art, deep black with subtle grain texture
- **Subject**: Centered soft-focus circular glow, deep blue to black gradient
- **Color Palette**: #000000, #0a1551, #1435a3
- **Generation Prompt**: "Create a high-resolution abstract digital background with a deep black base and a subtle, soft-focus circular glow transitioning from deep blue (#0a1551) at the center to black at the edges. The image should have a calm, mysterious, and slightly futuristic mood, with a gentle vignette effect and minimal noise for texture. No text or additional elements, just pure abstract ambiance."

### Motion Choreography

#### Entrance Sequence
| Element | Animation | Values | Duration | Delay | Easing |
|---------|-----------|--------|----------|-------|--------|
| Background | Zoom-Out & Blur-Clear | Scale 1.4→1, Blur 20px→0 | 1.8s | 0s | custom-expo |
| Headline Chars | 3D Flip & Drop | RotateX 90→0, Y -50→0 | 1.2s | 0.2s (stagger) | custom-expo |
| Timer Digits | Slot Machine Roll | Y -100%→0% | 1.5s | 0.8s | custom-expo |
| Controls | Elastic Scale | Scale 0→1 | 0.8s | 1.2s | elastic-snap |

#### Scroll Effects
| Trigger | Element | Effect | Start | End | Values |
|---------|---------|--------|-------|-----|--------|
| Scroll | Timer Container | Z-Depth Push | Top | Bottom | TranslateZ 0→-200px |
| Scroll | Background | Parallax | Top | Bottom | Y 0→30% |

#### Continuous Animations
- **Time Flow**: The colon separators blink with a "breathing" opacity (0.4 to 1.0).
- **Digit Glow**: The active digit (seconds) has a subtle pulsing outer glow (box-shadow).

#### Interaction Effects
- **Mouse Hover**: The timer digits slightly tilt towards the cursor (max 5deg) using 3D transforms.
- **Button Hover**: Magnetic pull on the button (moves 20% towards cursor) + Yellow background floods in from the cursor entry point.

## Section 2: Timer Input Modal

### Layout
**"Holographic Interface"**
The input form appears as a glass-morphism layer sliding over the hero.

#### Spatial Composition
- **Modal**: Centered, but uses a "curtain reveal" effect where it wipes away the background focus.
- **Form Grid**: Asymmetric layout, pushing labels to the edges and inputs to the center.

### Content
- **Title**: "Set Your Time"
- **Inputs**: Days, Hours, Minutes, Seconds (Number inputs)
- **Actions**: "Set Timer", "Cancel"

### Motion Choreography

#### Entrance Sequence
- **Backdrop**: Blur filter transitions from 0px to 20px.
- **Form Container**: Scales up from 0.8 with opacity, while rotating slightly from X-axis (Perspective open).

#### Interaction Effects
- **Input Focus**: The border draws itself (SVG stroke animation) in Yellow. The label floats up.
- **Number Scroll**: Inputs feature a "wheel" scroll interaction (simulated) where numbers roll into place.
- **Button Click**: A ripple effect expands from the click coordinates, filling the button.

## Section 3: Completion State

### Layout
**"Celebratory Burst"**
When the timer hits zero, the layout explodes outward (figuratively) with energy.

### Content
- **Message**: "TIME'S UP!"
- **Actions**: "Reset Timer", "Set New Timer"

### Motion Choreography

#### State Change Effects
- **Timer Digits**: Shake violently (2px, 10 times) then "pop" to 00:00:00:00.
- **Background**: A shockwave distortion ripples through the background image (using CSS filter or WebGL displacement if available, otherwise scale-pulse).
- **Message**: "TIME'S UP" text explodes inwards from large scale (scale 5→1) with a "glass shatter